var num1=23;
let num2='diana';
const num3=34;

const sum = num1+num2+num3;
console.log(`the sum is: ${sum}`);

let nombre:string= 'diana';
let edad:number = 21;
let activo: boolean = true;

let matricula:number|string;
matricula=20001034;
matricula='dgfd1034';
